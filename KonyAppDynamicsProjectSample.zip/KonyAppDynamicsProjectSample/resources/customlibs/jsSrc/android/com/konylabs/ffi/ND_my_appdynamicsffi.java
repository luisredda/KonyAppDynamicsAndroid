package com.konylabs.ffi;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;
import com.konylabs.api.TableLib;
import com.konylabs.vm.LuaTable;



import com.appdynamicsffi.sample.AppDynamics;
import com.konylabs.libintf.Library;
import com.konylabs.libintf.JSLibrary;
import com.konylabs.vm.LuaError;
import com.konylabs.vm.LuaNil;


public class ND_my_appdynamicsffi extends JSLibrary {

 
 
	public static final String initWithAppKey = "initWithAppKey";
 
 
	public static final String reportMetricWithNameAndCounter = "reportMetricWithNameAndCounter";
 
 
	public static final String setUserData = "setUserData";
 
	String[] methods = { initWithAppKey, reportMetricWithNameAndCounter, setUserData };


 Library libs[] = null;
 public Library[] getClasses() {
 libs = new Library[0];
 return libs;
 }



	public ND_my_appdynamicsffi(){
	}

	public Object[] execute(int index, Object[] params) {
		// TODO Auto-generated method stub
		Object[] ret = null;
 try {
		int paramLen = params.length;
 int inc = 1;
		switch (index) {
 		case 0:
 if (paramLen != 1){ return new Object[] {new Double(100),"Invalid Params"}; }
 java.lang.String key0 = null;
 if(params[0] != null && params[0] != LuaNil.nil) {
 key0 = (java.lang.String)params[0];
 }
 ret = this.initWithAppKey( key0 );
 
 			break;
 		case 1:
 if (paramLen != 2){ return new Object[] {new Double(100),"Invalid Params"}; }
 java.lang.String metricName1 = null;
 if(params[0] != null && params[0] != LuaNil.nil) {
 metricName1 = (java.lang.String)params[0];
 }
 Double counter1 = null;
 if(params[1] != null && params[1] != LuaNil.nil) {
 counter1 = (Double)params[1];
 }
 ret = this.reportMetricWithNameAndCounter( metricName1, counter1 );
 
 			break;
 		case 2:
 if (paramLen != 3){ return new Object[] {new Double(100),"Invalid Params"}; }
 java.lang.String key2 = null;
 if(params[0] != null && params[0] != LuaNil.nil) {
 key2 = (java.lang.String)params[0];
 }
 java.lang.String value2 = null;
 if(params[1] != null && params[1] != LuaNil.nil) {
 value2 = (java.lang.String)params[1];
 }
 Boolean persist2 = null;
 if(params[2] != null && params[2] != LuaNil.nil) {
 persist2 = (Boolean)params[2];
 }
 ret = this.setUserData( key2, value2, persist2 );
 
 			break;
 		default:
			break;
		}
 }catch (Exception e){
			ret = new Object[]{e.getMessage(), new Double(101), e.getMessage()};
		}
		return ret;
	}

	public String[] getMethods() {
		// TODO Auto-generated method stub
		return methods;
	}
	public String getNameSpace() {
		// TODO Auto-generated method stub
		return "my.appdynamicsffi";
	}


	/*
	 * return should be status(0 and !0),address
	 */
 
 
 	public final Object[] initWithAppKey( java.lang.String inputKey0 ){
 
		Object[] ret = null;
 com.appdynamicsffi.sample.AppDynamics.initWithAppKey( inputKey0
 );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] reportMetricWithNameAndCounter( java.lang.String inputKey0, Double inputKey1 ){
 
		Object[] ret = null;
 com.appdynamicsffi.sample.AppDynamics.reportMetricWithName( inputKey0
 , inputKey1.longValue() );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
 
 	public final Object[] setUserData( java.lang.String inputKey0, java.lang.String inputKey1, Boolean inputKey2 ){
 
		Object[] ret = null;
 com.appdynamicsffi.sample.AppDynamics.setUserData( inputKey0
 , inputKey1
 , inputKey2.booleanValue() );
 
 ret = new Object[]{LuaNil.nil, new Double(0)};
 		return ret;
	}
 
};
