function preAppInit(){
        kony.license.disableMetricReporting();
}

function postAppInit() {
    kony.print("before postAppInit");
    // initialize appdynamics
    my.appdynamicsffi.initWithAppKey("AD-AAB-AAB-REV");
     kony.print("after postAppInit");
}


function hitSomeService() {
    kony.print("hitSomeService");
    my.appdynamicsffi.reportMetricWithNameAndCounter("Google.com Hit", 1);
    
    var url = "http://www.google.com";
    var inputParam = {};
    inputParam["channel"] = "rc";
    inputParam["platformver"] = "6.0.GA_v201601211122_r35";
    inputParam["platform"] = kony.os.deviceInfo().name;
    var connHandle = kony.net.invokeServiceAsync(url, inputParam, callback)
}

function callback(result) {
    kony.print("callback result : " + result);
    //my.appdynamicsffi.setUserData("Response dump", result, false);
}