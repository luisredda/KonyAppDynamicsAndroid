//Form JS File
function frmHome_button1536412890571_onClick_seq0(eventobject) {
    hitSomeService.call(this);
};

function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var button1536412890571 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "height": "50dp",
        "id": "button1536412890571",
        "isVisible": true,
        "left": "10.22%",
        "onClick": frmHome_button1536412890571_onClick_seq0,
        "right": "9.78%",
        "skin": "btnNormal",
        "text": "Call a service",
        "top": "129dp",
        "width": "80%",
        "zIndex": 1
    }, {
        "containerWeight": 11,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var label419858790578 = new kony.ui.Label({
        "height": "26dp",
        "id": "label419858790578",
        "isVisible": true,
        "left": "1.56%",
        "right": "2.44%",
        "skin": "lblNormal",
        "text": "App Dynamics initialization triggered in Post App Init",
        "top": "70dp",
        "width": "96%",
        "zIndex": 1
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    frmHome.add(
    button1536412890571, label419858790578);
};

function frmHomeGlobals() {
    var MenuId = [];
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "bounces": true,
        "enabledForIdleTimeout": false,
        "enableScrolling": true,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "pagingEnabled": false,
        "skin": "bgskin",
        "title": null
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "formAnimation": 0
        },
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "outTransitionConfig": {
            "formAnimation": 0
        },
        "retainScrollPosition": false,
        "titleBar": true,
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};