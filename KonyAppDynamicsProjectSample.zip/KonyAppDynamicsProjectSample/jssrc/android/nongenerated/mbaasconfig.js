function getKonyMBAASAppKey() {
    return '${mbaasappkey}';
}

function getKonyMBAASAppSecret() {
    return '${mbaasappsecret}';
}